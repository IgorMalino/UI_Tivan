import React from 'react';

const Main = () => {

    return (
        <>
        <div className="interactive">

        </div>
        </>
    )
}

export default Main