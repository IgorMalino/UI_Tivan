export const enLanguage = {
    About : "ABOUT",
    Presale : "PRESALE",
    Gallery : "GALLERY",
    Game: "Game",
    Arena : "ARENA",
    Bank : "BANK",
    Market : "MARKET",
    Main_base : "MAIN BASE",
    Labs : "LABS",
    Wiki : "WIKI",
    News : "NEWS",
    Connect: "Connect",
    Control: "Control",
    Presale_Text: "End of presale in: GO BUY TVT",
    Choose_wallet:"CHOOSE WALLET",
    More_wallets_coming: "More wallets coming soon"
}