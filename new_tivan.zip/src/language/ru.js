export const ruLanguage = {
    About : "О Проекте",
    Presale : "ПРЕПРОДАЖА",
    Gallery : "ГАЛЛЕРЕЯ",
    Game: "Игра",
    Arena : "АРЕНА",
    Bank : "БАНК",
    Market : "МАРКЕТ",
    Main_base : "ГЛАВНАЯ БАЗА",
    Labs : "ЛАБОРАТОРИИ",
    Wiki : "ВИКИ",
    News : "НОВОСТИ",
    Connect: "Подключить",
    Control: "Контроль",
    Presale_Text: "Конец препродажи: Купите TVT",
    Choose_wallet:"ВЫБЕРИТЕ КОШЕЛЕК",
    More_wallets_coming: "Скоро появятся новые кошельки"
}